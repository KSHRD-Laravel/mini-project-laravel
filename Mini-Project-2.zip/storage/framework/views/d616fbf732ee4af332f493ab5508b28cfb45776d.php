<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6">
            <hr>
            <div class="form-outline mb-4">
            <input type="text" id="name" class="form-control" />
            <label class="form-label" for="name">Name</label>
            </div>

            <!-- Submit button -->
            <button type="button" id="create" class="btn btn-primary btn-block">Create</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
##parent-placeholder-cb5346a081dcf654061b7f897ea14d9b43140712##
<script>
    $(document).ready(function() {
        function createCategory() {
            let category = {
                "name": $("#name").val()
            }
            $.ajax({
                url: '/api/categories',
                method: 'POST',
                data: category,
                success: function(res) {
                    console.log(res)
                },
                error: function(err) {
                    console.log(err)
                }
            })
        }
        $("#create").on('click', function() {
            createCategory()
        })
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kimleang/Desktop/laravel-projs/mini-project-2/resources/views/category/create.blade.php ENDPATH**/ ?>